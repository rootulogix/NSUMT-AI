const TELEGRAM_FILE_TIMEOUT_MS = 45_000;
const MAX_TELEGRAM_MEDIA_BYTES = 10 * 1024 * 1024;

const SUPPORTED_MEDIA_MIME_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "audio/wav",
  "audio/mp3",
  "audio/aiff",
  "audio/aac",
  "audio/ogg",
  "audio/flac",
  "audio/mpeg",
  "audio/opus",
  "audio/alaw",
  "audio/mulaw",
  "audio/m4a",
  "audio/l16",
]);

type TelegramFileResponse = {
  ok: boolean;
  result?: {
    file_path?: string;
    file_size?: number;
  };
  error_code?: number;
};

export class TelegramMediaError extends Error {
  constructor(
    message: string,
    readonly statusCode?: number,
  ) {
    super(message);
    this.name = "TelegramMediaError";
  }
}

export class MediaPayloadTooLargeError extends Error {
  constructor() {
    super("The full conversation media exceeds Gemini's inline request limit");
    this.name = "MediaPayloadTooLargeError";
  }
}

export type DownloadedTelegramMedia = {
  mimeType: string;
  base64: string;
  byteLength: number;
};

export async function downloadTelegramMedia(
  telegramToken: string,
  fileId: string,
  mimeType: string,
  knownFileSize?: number,
): Promise<DownloadedTelegramMedia> {
  const normalizedMimeType = mimeType.toLowerCase().split(";")[0]?.trim();
  if (!normalizedMimeType || !SUPPORTED_MEDIA_MIME_TYPES.has(normalizedMimeType)) {
    throw new TelegramMediaError("This Telegram media format is not supported");
  }

  if (knownFileSize && knownFileSize > MAX_TELEGRAM_MEDIA_BYTES) {
    throw new TelegramMediaError("Telegram media is larger than the download limit");
  }

  const metadataResponse = await fetch(
    `https://api.telegram.org/bot${telegramToken}/getFile`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ file_id: fileId }),
      signal: AbortSignal.timeout(TELEGRAM_FILE_TIMEOUT_MS),
    },
  );
  const metadata = (await metadataResponse.json().catch(() => null)) as
    | TelegramFileResponse
    | null;

  if (!metadataResponse.ok || metadata?.ok !== true) {
    throw new TelegramMediaError(
      "Telegram could not prepare this media file",
      metadata?.error_code ?? metadataResponse.status,
    );
  }

  const filePath = metadata.result?.file_path;
  if (!filePath) {
    throw new TelegramMediaError("Telegram did not return a media file path");
  }

  const reportedSize = metadata.result?.file_size ?? knownFileSize;
  if (reportedSize && reportedSize > MAX_TELEGRAM_MEDIA_BYTES) {
    throw new TelegramMediaError("Telegram media is larger than the download limit");
  }

  const fileResponse = await fetch(
    `https://api.telegram.org/file/bot${telegramToken}/${filePath}`,
    { signal: AbortSignal.timeout(TELEGRAM_FILE_TIMEOUT_MS) },
  );
  if (!fileResponse.ok) {
    throw new TelegramMediaError(
      "Telegram media download failed",
      fileResponse.status,
    );
  }

  const contentLength = Number(fileResponse.headers.get("content-length"));
  if (Number.isFinite(contentLength) && contentLength > MAX_TELEGRAM_MEDIA_BYTES) {
    throw new TelegramMediaError("Telegram media is larger than the download limit");
  }

  const bytes = Buffer.from(await fileResponse.arrayBuffer());
  if (bytes.byteLength > MAX_TELEGRAM_MEDIA_BYTES) {
    throw new TelegramMediaError("Telegram media is larger than the download limit");
  }

  return {
    mimeType: normalizedMimeType,
    base64: bytes.toString("base64"),
    byteLength: bytes.byteLength,
  };
}
