import { setTimeout as delay } from "node:timers/promises";
import { and, asc, eq } from "drizzle-orm";
import { db, telegramConversations, telegramMessages } from "@workspace/db";
import {
  CREATOR_PROFILE_HTML,
  CREATOR_PROFILE_TEXT,
  isCreatorQuestion,
} from "./creator-profile";
import {
  downloadTelegramMedia,
  MediaPayloadTooLargeError,
  TelegramMediaError,
} from "./telegram-files";
import { logger } from "./logger";

const GEMINI_MODEL = "gemini-3.5-flash-lite";
const GEMINI_FALLBACK_MODEL = "gemini-3.8-flash";
const TELEGRAM_POLL_SECONDS = 25;
const TELEGRAM_REQUEST_TIMEOUT_MS = 35_000;
const GEMINI_TEXT_REQUEST_TIMEOUT_MS = 25_000;
const GEMINI_AUDIO_REQUEST_TIMEOUT_MS = 45_000;
const TELEGRAM_MESSAGE_LIMIT = 4_000;
const GEMINI_RETRY_DELAYS_MS = [1_000, 2_000];
const MAX_GEMINI_INLINE_MEDIA_BYTES = 12 * 1024 * 1024;
const MAX_TELEGRAM_MEDIA_BYTES = 10 * 1024 * 1024;

type TelegramFileAttachment = {
  file_id: string;
  file_size?: number;
  mime_type?: string;
};

type TelegramUpdate = {
  update_id: number;
  message?: {
    chat: { id: number };
    from?: {
      id: number;
      is_bot?: boolean;
      first_name?: string;
      last_name?: string;
      username?: string;
    };
    text?: string;
    caption?: string;
    photo?: Array<{
      file_id: string;
      file_size?: number;
      width: number;
      height: number;
    }>;
    voice?: TelegramFileAttachment;
    audio?: TelegramFileAttachment;
    document?: TelegramFileAttachment;
  };
};

type TelegramApiResponse<T> = {
  ok: boolean;
  result?: T;
  error_code?: number;
  parameters?: { retry_after?: number };
};

type TelegramWebhookInfo = {
  url?: string;
  pending_update_count?: number;
};

type GeminiApiResponse = {
  candidates?: Array<{
    content?: {
      parts?: Array<{ text?: string }>;
    };
  }>;
};

type TelegramHistoryItem = {
  id: number;
  role: "user" | "assistant";
  content: string;
  mediaKind: "image" | "audio" | null;
  mediaFileId: string | null;
  mediaMimeType: string | null;
};

type GeminiReply = {
  text: string;
  transcription?: string;
};

type GeminiPart = {
  text?: string;
  inlineData?: {
    mimeType: string;
    data: string;
  };
};

type BotConfig = {
  telegramToken: string;
  geminiApiKey: string;
};

class TelegramApiError extends Error {
  constructor(
    readonly method: string,
    readonly statusCode: number,
    readonly retryAfterSeconds?: number,
  ) {
    super(`Telegram ${method} failed with status ${statusCode}`);
    this.name = "TelegramApiError";
  }
}

class GeminiApiError extends Error {
  constructor(
    readonly statusCode: number,
    readonly retryAfterMs?: number,
  ) {
    super(`Gemini request failed with status ${statusCode}`);
    this.name = "GeminiApiError";
  }
}

class GeminiResponseFormatError extends Error {
  constructor() {
    super("Gemini returned an invalid voice response");
    this.name = "GeminiResponseFormatError";
  }
}

class GeminiTimeoutError extends Error {
  constructor(readonly timeoutMs: number) {
    super(`Gemini request exceeded ${timeoutMs}ms`);
    this.name = "GeminiTimeoutError";
  }
}

function safeErrorMetadata(error: unknown): {
  errorName: string;
  errorCode?: string;
  statusCode?: number;
  timeoutMs?: number;
} {
  const record =
    typeof error === "object" && error !== null
      ? (error as { code?: unknown })
      : undefined;

  return {
    errorName: error instanceof Error ? error.name : typeof error,
    errorCode: typeof record?.code === "string" ? record.code : undefined,
    statusCode:
      error instanceof GeminiApiError ||
      error instanceof TelegramMediaError ||
      error instanceof TelegramApiError
        ? error.statusCode
        : undefined,
    timeoutMs:
      error instanceof GeminiTimeoutError ? error.timeoutMs : undefined,
  };
}

function isRetryableGeminiFailure(error: unknown): boolean {
  if (error instanceof GeminiApiError) {
    return [429, 500, 502, 503, 504].includes(error.statusCode);
  }

  return (
    error instanceof TypeError ||
    (error instanceof Error && error.name === "AbortError")
  );
}

async function telegramRequest<T>(
  config: BotConfig,
  method: string,
  body: Record<string, unknown>,
): Promise<T> {
  const response = await fetch(
    `https://api.telegram.org/bot${config.telegramToken}/${method}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(TELEGRAM_REQUEST_TIMEOUT_MS),
    },
  );

  const result = (await response.json().catch(() => null)) as
    | TelegramApiResponse<T>
    | null;

  if (!response.ok || result?.ok !== true) {
    throw new TelegramApiError(
      method,
      result?.error_code ?? response.status,
      result?.parameters?.retry_after,
    );
  }

  return result.result as T;
}

async function generateGeminiReply(
  config: BotConfig,
  history: TelegramHistoryItem[],
  voiceMessageId?: number,
): Promise<GeminiReply> {
  const contents: Array<{
    role: "user" | "model";
    parts: GeminiPart[];
  }> = [];
  let totalMediaBytes = 0;

  for (const message of history) {
    const parts: GeminiPart[] = [];

    if (
      message.mediaFileId &&
      message.mediaMimeType &&
      message.mediaKind
    ) {
      let media;
      try {
        media = await downloadTelegramMedia(
          config.telegramToken,
          message.mediaFileId,
          message.mediaMimeType,
        );
      } catch (error) {
        if (error instanceof TelegramMediaError) throw error;
        throw new TelegramMediaError("Telegram media download failed");
      }
      totalMediaBytes += media.byteLength;
      if (totalMediaBytes > MAX_GEMINI_INLINE_MEDIA_BYTES) {
        throw new MediaPayloadTooLargeError();
      }
      parts.push({
        inlineData: {
          mimeType: media.mimeType,
          data: media.base64,
        },
      });
    }

    if (message.content) {
      parts.push({ text: message.content });
    }

    if (message.id === voiceMessageId) {
      parts.push({
        text: "Распознай речь в прикреплённом голосовом сообщении на языке оригинала. Используй её как последнюю реплику пользователя, учти предыдущую историю и ответь по сути. Верни только JSON с полями transcript (точная расшифровка) и answer (ответ пользователю на русском языке).",
      });
    } else if (message.mediaKind === "audio" && message.mediaFileId) {
      parts.push({
        text: "Это более раннее голосовое сообщение пользователя; учитывай его содержание как часть истории.",
      });
    }

    contents.push({
      role: message.role === "assistant" ? "model" : "user",
      parts,
    });
  }

  const requestTimeoutMs = contents.some((content) =>
    content.parts.some(
      (part) => part.inlineData?.mimeType.startsWith("audio/") ?? false,
    ),
  )
    ? GEMINI_AUDIO_REQUEST_TIMEOUT_MS
    : GEMINI_TEXT_REQUEST_TIMEOUT_MS;

  const models = [GEMINI_MODEL, GEMINI_FALLBACK_MODEL];
  let result: GeminiApiResponse | undefined;

  for (let modelIndex = 0; modelIndex < models.length; modelIndex += 1) {
    const model = models[modelIndex];
    if (!model) continue;

    for (
      let attempt = 0;
      attempt <= GEMINI_RETRY_DELAYS_MS.length;
      attempt += 1
    ) {
      try {
        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "x-goog-api-key": config.geminiApiKey,
            },
            body: JSON.stringify({
              contents,
              ...(voiceMessageId
                ? { generationConfig: { responseMimeType: "application/json" } }
                : {}),
            }),
            signal: AbortSignal.timeout(requestTimeoutMs),
          },
        );

        if (!response.ok) {
          const retryAfterHeader = response.headers.get("retry-after");
          const retryAfterSeconds = retryAfterHeader
            ? Number(retryAfterHeader)
            : Number.NaN;
          const retryAfterDate = retryAfterHeader
            ? Date.parse(retryAfterHeader)
            : Number.NaN;
          const retryAfterMs = Number.isFinite(retryAfterSeconds)
            ? Math.max(0, retryAfterSeconds * 1_000)
            : Number.isFinite(retryAfterDate)
              ? Math.max(0, retryAfterDate - Date.now())
              : undefined;
          throw new GeminiApiError(response.status, retryAfterMs);
        }

        result = (await response.json()) as GeminiApiResponse;
        if (modelIndex > 0) {
          logger.warn(
            {
              model: GEMINI_MODEL,
              fallbackModel: model,
            },
            "Primary Gemini model unavailable; fallback model succeeded",
          );
        }
        break;
      } catch (error) {
        if (error instanceof Error && error.name === "TimeoutError") {
          throw new GeminiTimeoutError(requestTimeoutMs);
        }

        const shouldRetry =
          attempt < GEMINI_RETRY_DELAYS_MS.length &&
          isRetryableGeminiFailure(error) &&
          !(
            error instanceof GeminiApiError &&
            error.retryAfterMs !== undefined &&
            error.retryAfterMs > 5_000
          );

        if (shouldRetry) {
          const retryDelayMs =
            error instanceof GeminiApiError && error.retryAfterMs !== undefined
              ? Math.min(error.retryAfterMs, 5_000)
              : (GEMINI_RETRY_DELAYS_MS[attempt] ?? 2_000) +
                Math.floor(Math.random() * 251);
          await delay(retryDelayMs);
          continue;
        }

        const canUseFallback =
          modelIndex < models.length - 1 &&
          error instanceof GeminiApiError &&
          [500, 502, 503, 504].includes(error.statusCode);
        if (canUseFallback) {
          logger.warn(
            { model, statusCode: error.statusCode },
            "Gemini model unavailable; switching to fallback model",
          );
          break;
        }

        throw error;
      }
    }

    if (result) break;
  }

  if (!result) {
    throw new Error("Gemini request exhausted all model attempts");
  }

  const text = result.candidates?.[0]?.content?.parts
    ?.map((part) => part.text ?? "")
    .join("")
    .trim();

  if (!text) {
    return {
      text: "Не удалось получить текстовый ответ. Попробуй задать вопрос иначе.",
    };
  }

  if (voiceMessageId) {
    let parsed: unknown;
    try {
      parsed = JSON.parse(text);
    } catch {
      throw new GeminiResponseFormatError();
    }

    if (
      typeof parsed !== "object" ||
      parsed === null ||
      !("transcript" in parsed) ||
      typeof parsed.transcript !== "string" ||
      !parsed.transcript.trim() ||
      !("answer" in parsed) ||
      typeof parsed.answer !== "string" ||
      !parsed.answer.trim()
    ) {
      throw new GeminiResponseFormatError();
    }

    return {
      text: parsed.answer.trim(),
      transcription: parsed.transcript.trim(),
    };
  }

  return { text };
}

async function sendTelegramText(
  config: BotConfig,
  chatId: number,
  text: string,
  parseMode?: "HTML",
): Promise<void> {
  const characters = Array.from(text);

  for (let offset = 0; offset < characters.length; offset += TELEGRAM_MESSAGE_LIMIT) {
    const part = characters.slice(offset, offset + TELEGRAM_MESSAGE_LIMIT).join("");
    await telegramRequest(config, "sendMessage", {
      chat_id: chatId,
      text: part,
      ...(parseMode ? { parse_mode: parseMode } : {}),
    });
  }
}

type TelegramIdentity = {
  chatId: string;
  userId: string;
  username: string | null;
  displayName: string | null;
};

type IncomingTelegramMedia = {
  kind: "image" | "audio";
  fileId: string;
  mimeType: string;
  fileSize?: number;
};

type TelegramConversation = typeof telegramConversations.$inferSelect;

const HISTORY_CONSENT_NOTICE =
  "Перед началом: я сохраняю текст сообщений, расшифровки голосовых и ответы в отдельной истории этого чата. Фото и голосовые отправляются Gemini для обработки; вся текстовая история используется при каждом ответе. История хранится, пока вы не отправите /forget. Чтобы продолжить, отправьте /agree.";

function getTelegramIdentity(
  message: NonNullable<TelegramUpdate["message"]>,
): TelegramIdentity | undefined {
  const sender = message.from;
  if (!sender || sender.is_bot) return undefined;

  const displayName = [sender.first_name, sender.last_name]
    .filter((part): part is string => Boolean(part?.trim()))
    .join(" ");

  return {
    chatId: String(message.chat.id),
    userId: String(sender.id),
    username: sender.username ?? null,
    displayName: displayName || null,
  };
}

function getIncomingTelegramMedia(
  message: NonNullable<TelegramUpdate["message"]>,
): IncomingTelegramMedia | undefined {
  const photo = message.photo?.at(-1);
  if (photo) {
    return {
      kind: "image",
      fileId: photo.file_id,
      mimeType: "image/jpeg",
      fileSize: photo.file_size,
    };
  }

  const document = message.document;
  if (
    document?.mime_type &&
    ["image/jpeg", "image/png", "image/webp", "image/gif"].includes(
      document.mime_type.toLowerCase(),
    )
  ) {
    return {
      kind: "image",
      fileId: document.file_id,
      mimeType: document.mime_type.toLowerCase(),
      fileSize: document.file_size,
    };
  }

  if (message.voice) {
    return {
      kind: "audio",
      fileId: message.voice.file_id,
      mimeType: message.voice.mime_type ?? "audio/ogg",
      fileSize: message.voice.file_size,
    };
  }

  if (message.audio) {
    return {
      kind: "audio",
      fileId: message.audio.file_id,
      mimeType: message.audio.mime_type ?? "audio/mpeg",
      fileSize: message.audio.file_size,
    };
  }

  return undefined;
}

async function findConversation(
  identity: TelegramIdentity,
): Promise<TelegramConversation | undefined> {
  const [conversation] = await db
    .select()
    .from(telegramConversations)
    .where(
      and(
        eq(telegramConversations.telegramChatId, identity.chatId),
        eq(telegramConversations.telegramUserId, identity.userId),
      ),
    )
    .limit(1);

  return conversation;
}

async function createConsentedConversation(
  identity: TelegramIdentity,
): Promise<TelegramConversation> {
  const now = new Date();
  const [conversation] = await db
    .insert(telegramConversations)
    .values({
      telegramChatId: identity.chatId,
      telegramUserId: identity.userId,
      username: identity.username,
      displayName: identity.displayName,
      consentedAt: now,
      updatedAt: now,
    })
    .onConflictDoUpdate({
      target: [
        telegramConversations.telegramChatId,
        telegramConversations.telegramUserId,
      ],
      set: {
        username: identity.username,
        displayName: identity.displayName,
        updatedAt: now,
      },
    })
    .returning();

  if (!conversation) {
    throw new Error("Could not create Telegram conversation");
  }

  return conversation;
}

async function refreshConversationProfile(
  conversationId: number,
  identity: TelegramIdentity,
): Promise<void> {
  await db
    .update(telegramConversations)
    .set({
      username: identity.username,
      displayName: identity.displayName,
      updatedAt: new Date(),
    })
    .where(eq(telegramConversations.id, conversationId));
}

async function sendStorageError(
  config: BotConfig,
  chatId: number,
): Promise<void> {
  try {
    await sendTelegramText(
      config,
      chatId,
      "Не удалось сохранить историю. Попробуй ещё раз позже.",
    );
  } catch {
    logger.error("Could not notify Telegram user about a storage failure");
  }
}

async function handleMessage(
  config: BotConfig,
  message: NonNullable<TelegramUpdate["message"]>,
): Promise<void> {
  const identity = getTelegramIdentity(message);
  if (!identity) return;

  const chatId = message.chat.id;
  const commandInput = message.text?.trim() ?? "";
  const input = commandInput || message.caption?.trim() || "";
  const incomingMedia = getIncomingTelegramMedia(message);
  const isCommand = (name: string) =>
    new RegExp(`^\\/${name}(?:@[A-Za-z0-9_]+)?(?:\\s|$)`).test(commandInput);

  if (isCreatorQuestion(input)) {
    await sendTelegramText(config, chatId, CREATOR_PROFILE_HTML, "HTML");
    return;
  }

  if (isCommand("start")) {
    let conversation: TelegramConversation | undefined;
    try {
      conversation = await findConversation(identity);
    } catch {
      logger.error("Could not read Telegram conversation");
      await sendStorageError(config, chatId);
      return;
    }

    if (conversation?.consentedAt) {
      const greeting = identity.displayName
        ? `Привет, ${identity.displayName}!`
        : "Привет!";
      await sendTelegramText(
        config,
        chatId,
        `${greeting} Я сохраняю историю отдельно для вас в этом чате. Отправьте /forget, чтобы удалить её.`,
      );
    } else {
      await sendTelegramText(config, chatId, HISTORY_CONSENT_NOTICE);
    }
    return;
  }

  if (isCommand("agree")) {
    try {
      await createConsentedConversation(identity);
      await sendTelegramText(
        config,
        chatId,
        "Готово. Текст сообщений, расшифровки голосовых и ответы будут сохраняться только в вашей истории этого чата. Фото и голосовые будут передаваться Gemini для обработки. Отправьте /forget, чтобы удалить историю.",
      );
    } catch {
      logger.error("Could not record Telegram history consent");
      await sendStorageError(config, chatId);
    }
    return;
  }

  if (isCommand("forget")) {
    try {
      const conversation = await findConversation(identity);
      if (conversation) {
        await db
          .delete(telegramConversations)
          .where(eq(telegramConversations.id, conversation.id));
      }
      await sendTelegramText(
        config,
        chatId,
        conversation
          ? "Ваша история этого чата удалена."
          : "Сохранённой истории в этом чате нет.",
      );
    } catch {
      logger.error("Could not delete Telegram conversation history");
      await sendStorageError(config, chatId);
    }
    return;
  }

  let conversation: TelegramConversation | undefined;
  try {
    conversation = await findConversation(identity);
  } catch {
    logger.error("Could not read Telegram conversation");
    await sendStorageError(config, chatId);
    return;
  }

  if (!conversation?.consentedAt) {
    await sendTelegramText(config, chatId, HISTORY_CONSENT_NOTICE);
    return;
  }

  if (!input && !incomingMedia) {
    await sendTelegramText(
      config,
      chatId,
      "Отправь текст, голосовое сообщение или изображение.",
    );
    return;
  }

  if (
    incomingMedia?.fileSize &&
    incomingMedia.fileSize > MAX_TELEGRAM_MEDIA_BYTES
  ) {
    await sendTelegramText(
      config,
      chatId,
      "Файл слишком большой для обработки. Отправь изображение сжато или более короткое голосовое сообщение.",
    );
    return;
  }

  const userContent =
    incomingMedia?.kind === "audio"
      ? input
        ? `Подпись к голосовому сообщению: ${input}`
        : "Голосовое сообщение — ожидается распознавание."
      : incomingMedia?.kind === "image"
        ? input || "Пользователь отправил изображение. Опиши его."
        : input;

  let userMessageId: number;
  try {
    await refreshConversationProfile(conversation.id, identity);
    const [savedMessage] = await db
      .insert(telegramMessages)
      .values({
        conversationId: conversation.id,
        role: "user",
        content: userContent,
        mediaKind: incomingMedia?.kind ?? null,
        mediaFileId: incomingMedia?.fileId ?? null,
        mediaMimeType: incomingMedia?.mimeType ?? null,
      })
      .returning({ id: telegramMessages.id });
    if (!savedMessage) {
      throw new Error("Could not save Telegram message");
    }
    userMessageId = savedMessage.id;
  } catch (error) {
    logger.error(
      safeErrorMetadata(error),
      "Could not save Telegram user message",
    );
    await sendStorageError(config, chatId);
    return;
  }

  try {
    await telegramRequest(config, "sendChatAction", {
      chat_id: chatId,
      action: "typing",
    });
  } catch (error) {
    logger.warn(
      {
        statusCode:
          error instanceof TelegramApiError ? error.statusCode : undefined,
      },
      "Could not send Telegram typing status",
    );
  }

  let history: TelegramHistoryItem[];
  try {
    history = await db
      .select({
        id: telegramMessages.id,
        role: telegramMessages.role,
        content: telegramMessages.content,
        mediaKind: telegramMessages.mediaKind,
        mediaFileId: telegramMessages.mediaFileId,
        mediaMimeType: telegramMessages.mediaMimeType,
      })
      .from(telegramMessages)
      .where(eq(telegramMessages.conversationId, conversation.id))
      .orderBy(asc(telegramMessages.id));
  } catch (error) {
    logger.error(
      safeErrorMetadata(error),
      "Could not load Telegram conversation history",
    );
    await sendStorageError(config, chatId);
    return;
  }

  let generated: GeminiReply | undefined;
  let reply: string;
  let formatReplyAsHtml = false;
  let mediaProcessed = false;
  try {
    generated = await generateGeminiReply(
      config,
      history,
      incomingMedia?.kind === "audio" ? userMessageId : undefined,
    );
    reply = generated.text;
    mediaProcessed = true;

    if (
      generated.transcription &&
      isCreatorQuestion(generated.transcription)
    ) {
      reply = CREATOR_PROFILE_TEXT;
      formatReplyAsHtml = true;
    }
  } catch (error) {
    if (error instanceof MediaPayloadTooLargeError) {
      logger.warn(
        { conversationId: conversation.id },
        "Conversation media exceeds the Gemini inline request limit",
      );
      reply =
        "В этой истории накопилось слишком много изображений или аудио для одного запроса. Удали историю командой /forget, чтобы начать заново.";
    } else if (error instanceof TelegramMediaError) {
      logger.warn(
        safeErrorMetadata(error),
        "Could not download Telegram media",
      );
      reply =
        "Не удалось загрузить голосовое сообщение или изображение из Telegram. Отправь файл ещё раз.";
    } else if (error instanceof GeminiResponseFormatError) {
      logger.warn(
        safeErrorMetadata(error),
        "Gemini returned an invalid voice transcription response",
      );
      reply =
        "Не удалось распознать голосовое сообщение. Попробуй записать его ещё раз или отправь текстом.";
    } else if (error instanceof GeminiTimeoutError) {
      logger.warn(
        safeErrorMetadata(error),
        "Gemini response timed out",
      );
      const timeoutSeconds = Math.round(error.timeoutMs / 1_000);
      reply = `Gemini не успела ответить за ${timeoutSeconds} секунд. Твоё сообщение сохранено; отправь его ещё раз чуть позже.`;
    } else if (error instanceof GeminiApiError) {
      logger.error(
        { statusCode: error.statusCode },
        "Gemini request failed after retries",
      );
      reply = `Gemini временно не ответила (ошибка ${error.statusCode}). Твоё сообщение сохранено; попробуй ещё раз позже.`;
    } else {
      logger.error(
        safeErrorMetadata(error),
        "Gemini connection failed after retries",
      );
      reply =
        "Не удалось связаться с Gemini. Твоё сообщение сохранено; попробуй ещё раз через минуту.";
    }
  }

  try {
    await db.transaction(async (transaction) => {
      if (mediaProcessed && incomingMedia) {
        const transcription = generated?.transcription;
        await transaction
          .update(telegramMessages)
          .set({
            ...(transcription
              ? {
                  content: [
                    input ? `Подпись: ${input}` : "",
                    `Распознанная речь: ${transcription}`,
                  ]
                    .filter(Boolean)
                    .join("\n"),
                }
              : {}),
            mediaKind: null,
            mediaFileId: null,
            mediaMimeType: null,
          })
          .where(eq(telegramMessages.id, userMessageId));
      }

      await transaction.insert(telegramMessages).values({
        conversationId: conversation.id,
        role: "assistant",
        content: reply,
      });
    });
  } catch (error) {
    logger.error(
      safeErrorMetadata(error),
      "Could not save Gemini response",
    );
    try {
      await sendTelegramText(config, chatId, reply);
      await sendTelegramText(
        config,
        chatId,
        "Ответ отправлен, но его не удалось добавить в историю.",
      );
    } catch {
      logger.error("Could not deliver reply after a history write failure");
    }
    return;
  }

  try {
    await sendTelegramText(
      config,
      chatId,
      formatReplyAsHtml ? CREATOR_PROFILE_HTML : reply,
      formatReplyAsHtml ? "HTML" : undefined,
    );
  } catch (error) {
    logger.error(
      {
        statusCode:
          error instanceof TelegramApiError ? error.statusCode : undefined,
      },
      "Could not send Telegram reply",
    );
  }
}

async function pollTelegram(config: BotConfig): Promise<void> {
  let offset: number | undefined;
  let retryDelayMs = 1_000;

  try {
    const webhook = await telegramRequest<TelegramWebhookInfo>(
      config,
      "getWebhookInfo",
      {},
    );
    if (webhook.url) {
      await telegramRequest(config, "deleteWebhook", {
        drop_pending_updates: false,
      });
      logger.warn(
        { pendingUpdateCount: webhook.pending_update_count ?? 0 },
        "Removed the existing Telegram webhook to enable long polling; pending updates were preserved",
      );
    }
  } catch (error) {
    logger.warn(
      {
        statusCode:
          error instanceof TelegramApiError ? error.statusCode : undefined,
      },
      "Could not check Telegram webhook before starting long polling",
    );
  }

  while (true) {
    try {
      const request: Record<string, unknown> = {
        timeout: TELEGRAM_POLL_SECONDS,
        allowed_updates: ["message"],
      };
      if (offset !== undefined) request.offset = offset;

      const updates = await telegramRequest<TelegramUpdate[]>(
        config,
        "getUpdates",
        request,
      );
      retryDelayMs = 1_000;

      for (const update of updates) {
        offset = update.update_id + 1;
        if (!update.message) continue;

        try {
          await handleMessage(config, update.message);
        } catch (error) {
          logger.error(
            {
              statusCode:
                error instanceof TelegramApiError ? error.statusCode : undefined,
            },
            "Could not process Telegram message",
          );
        }
      }
    } catch (error) {
      const retryAfterMs =
        error instanceof TelegramApiError && error.retryAfterSeconds
          ? error.retryAfterSeconds * 1_000
          : retryDelayMs;

      logger.error(
        {
          method: error instanceof TelegramApiError ? error.method : "getUpdates",
          statusCode:
            error instanceof TelegramApiError ? error.statusCode : undefined,
          retryDelayMs: retryAfterMs,
        },
        error instanceof TelegramApiError && error.statusCode === 409
          ? "Telegram polling conflict: another polling instance may be active"
          : "Telegram polling failed; retrying",
      );

      await delay(retryAfterMs);
      retryDelayMs = Math.min(retryDelayMs * 2, 30_000);
    }
  }
}

export function startTelegramBot(): void {
  const telegramToken = process.env["TELEGRAM_BOT_TOKEN"];
  const geminiApiKey = process.env["GEMINI_API_KEY"];

  if (!telegramToken || !geminiApiKey) {
    throw new Error(
      "TELEGRAM_BOT_TOKEN and GEMINI_API_KEY must be set to start the Telegram bot.",
    );
  }

  logger.info(
    { model: GEMINI_MODEL, fallbackModel: GEMINI_FALLBACK_MODEL },
    "Starting Telegram bot polling",
  );
  void pollTelegram({ telegramToken, geminiApiKey }).catch(() => {
    logger.fatal("Telegram bot polling stopped unexpectedly");
  });
}
