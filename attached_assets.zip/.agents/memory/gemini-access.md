---
name: Gemini API access
description: Provider choice for Gemini-backed runtime features in this project.
---

Use the user's direct Gemini API key stored in Replit Secrets for Gemini runtime requests. Replit AI Integration provisioning was declined for this project.

**Why:** the user declined the account upgrade required for the Replit AI Integration and supplied a new direct Gemini API key.

**How to apply:** Continue using `GEMINI_API_KEY` for Gemini features in this project. Do not retry Replit AI Integration setup unless the user asks.
