---
name: Telegram history and hosting
description: User decisions about full Gemini conversation context and external always-on hosting.
---

For this bot, keep each consented history isolated by Telegram chat and user, and send the entire stored history to Gemini on every response. The user chose this explicitly. The user also chose a bot-only product with separate hosting instructions rather than adding a web page, and emphasized reliable automatic question-and-answer behavior.

**Why:** The user wants the bot to remember every conversation separately, run continuously outside Replit, and answer reliably.

**How to apply:** Do not truncate or summarize history without asking first. Keep database failures distinct from Gemini errors. Retry short transient provider/network failures with bounded backoff, and switch from Flash-Lite to the supported Flash fallback after repeated server-side 5xx errors. Do not retry a timed-out generation because it prolongs the user's wait; report its timeout clearly. When advising an external host, explain that Colab is not a dependable 24/7 service, use a durable PostgreSQL database, and ensure only one polling instance is active. History and Replit environment secrets are not automatically transferred to another host.
